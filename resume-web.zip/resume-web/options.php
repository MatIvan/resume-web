<?php
 $infoFIO     = 'Фамилия Имя Отчество';
 $infoPhone   = '+0 111 222 33 44';
 $infoEmail   = 'mymail@gmail.co';
 $infoUrlUrl  = 'https://mywebpage.wp';
 $infoUrlTxt  = 'mywebpage.wp';
 $infoGitUrl  = 'https://github.com/MatIvan';
 $infoGitTxt  = 'MatIvan';
?>