<nav>
  <ul>
    <li><a href="index.php?content=aducation">Образование</a></li>
    <li><a href="index.php?content=experience">Опыт работы</a></li>
    <li><a href="index.php?content=skills">Навыки</a></li>
    <li><a href="index.php?content=interests">Интересы</a></li>
    <li><a href="index.php?content=photos">Фотографии</a></li>
  </ul>
</nav>