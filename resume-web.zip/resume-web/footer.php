<footer>
    <div id="copyrigth">
      <span><?php echo $infoFIO ?> - Сайт разработан самостоятельно в 2018 году. </span>
    </div>
    
    <ul>
      <li> <hr> </li>
      <li> tel: <?php echo $infoPhone ?></li>
      <li> <a href="mailto:<?php echo $infoEmail ?>"><?php echo $infoEmail ?></a></li>
      <li> <a href="<?php echo $infoUrlUrl ?>"><?php echo $infoUrlTxt ?></a></li>
      <li> <a href="<?php echo $infoGitUrl ?>"><?php echo $infoGitTxt ?></a></li>
      <li> <hr> </li>
    </ul>
    
		</div>
    	
  </footer>

</body>
</html>
