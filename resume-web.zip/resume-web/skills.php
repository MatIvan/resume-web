<main>
     <section class="navleft">
     <h2>Разделы:</h2>
      <ul>
        <li><a href="#">пункт меню</a></li>
        <li><a href="#">пункт меню</a></li>
        <li><a href="#">пункт меню</a></li>
        <li><a href="#">пункт меню</a></li>
        <li><a href="#">пункт меню</a></li>
      </ul>
    </section>
    
    <section class="content">
    
    	<article>
			  <div class="article-title">
				  <span>Глава 1</span>
			  </div>
			  <p><b>НАВЫКИ</b></p>
			  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cum ullam harum, veniam aspernatur et obcaecati excepturi repudiandae esse, iusto consequatur dignissimos ipsum vitae tempore repellendus adipisci. Temporibus officia, adipisci veniam provident nobis rem quia corporis sit culpa, dolorem ipsam itaque cum iusto nesciunt error consectetur eligendi illo. Aspernatur asperiores dolores autem obcaecati! Eum cumque enim ab sunt rerum nihil, repudiandae minus sit aspernatur deserunt, recusandae cum unde tenetur laborum quidem mollitia nobis ut tempora, dicta deleniti necessitatibus inventore nulla tempore at! Et, neque sint unde excepturi tempora, nobis recusandae ut? Veniam, hic reprehenderit quas! Atque, quos, ea. Accusamus, fuga, labore.</p>
		  </article>

		  <article>
			  <div class="article-title">
				  <span>Глава 2</span>
			  </div>
			  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cum ullam harum, veniam aspernatur et obcaecati excepturi repudiandae esse, iusto consequatur dignissimos ipsum vitae tempore repellendus adipisci. Temporibus officia, adipisci veniam provident nobis rem quia corporis sit culpa, dolorem ipsam itaque cum iusto nesciunt error consectetur eligendi illo. Aspernatur asperiores dolores autem obcaecati! Eum cumque enim ab sunt rerum nihil, repudiandae minus sit aspernatur deserunt, recusandae cum unde tenetur laborum quidem mollitia nobis ut tempora, dicta deleniti necessitatibus inventore nulla tempore at! Et, neque sint unde excepturi tempora, nobis recusandae ut? Veniam, hic reprehenderit quas! Atque, quos, ea. Accusamus, fuga, labore.</p>
		  </article>
		  
    </section>
    
</main>